볼파이트 안드로이드 앱 프로젝트

이 프로젝트는 기존 볼파이트 HTML을 Android WebView 안에서 오프라인 실행하는 앱 래퍼입니다.

APK 빌드 방법
1. PC에 Android Studio를 설치합니다.
2. Android Studio에서 이 폴더(BallFightAndroid)를 Open 합니다.
3. Gradle Sync가 끝나면 Build > Build Bundle(s) / APK(s) > Build APK(s)를 선택합니다.
4. 빌드된 APK는 app/build/outputs/apk/debug/app-debug.apk 에 생성됩니다.
5. APK를 안드로이드 휴대폰으로 옮겨 설치합니다. 설치 시 출처를 알 수 없는 앱 허용이 필요할 수 있습니다.

앱 설정
- 앱 이름: 볼파이트
- 가로 화면, 전체 화면
- HTML 및 이미지가 앱 내부 assets에 포함되어 오프라인 실행 가능하도록 구성
- 패키지 ID: com.ballfight.game

참고: 이 환경에는 Android SDK/Gradle 빌드 도구가 없어 APK 자체를 여기서 빌드하거나 실기기 실행 검증하지 못했습니다. 프로젝트는 Android Studio에서 빌드할 수 있도록 구성했습니다.
